## maptesting
#### 1. Testig of leaflet js with leaflet routing machine for finding a varying destination for movable/searchable location against a fixed source in map
#### 2. Should be able to find how far the user is away from a given place (Given place is hard coded, should be getting from a script backend).
